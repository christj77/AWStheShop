import React from 'react'

export const Category = () => {
  return (
    <h1> Categories</h1>
  )
}

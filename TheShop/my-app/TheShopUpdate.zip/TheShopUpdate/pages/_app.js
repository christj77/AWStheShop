
import '@/styles/globals.css'
 
const uri="mongodb+srv://christj77:1234@cluster0.aqo88ro.mongodb.net/TheShop?retryWrites=true&w=majority";




export default function App({ Component, pageProps }) {
  return <Component 
  

  {...pageProps} />
}


